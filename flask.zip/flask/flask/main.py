from flask import Flask,render_template,request

import mysql.connector as mysql 
import os

app=Flask(__name__)
@app.route('/')
def home():

    return"welcome our first web page"
#front end to backend...
@app.route('/index')
def index():
    return render_template("index.html")
@app.route('/about')
def about():
    return render_template("about.html")
@app.route('/contact')
def contact():
    return render_template("contact.html")
@app.route('/Review')
def Review():
    return render_template("Review.html")
@app.route('/feedback')
def feedback():
    return render_template("Feedback.html")
@app.route('/login')
def login():
    return render_template("login.html")
# con={
#     'host':"localhost",'user':"root",'password':'2005','database':"fb"
# }

con={
    'host':"localhost",'user':"root",'password':'2005','database':"website"
}
# def get_db_connection():
#     return mysql.connect(**con)
# @app.route('/done',methods=['POST'])
# def submit():
#     if request.method=='POST':
#         id=request.form['id']
#         name=request.form['name']
#         email=request.form['email']
#         password=request.form['password']
#         connection=get_db_connection()
#         cursor=connection.cursor()

#         cursor.execute('INSERT into tbldata(id,name,email,password) values (%s,%s,%s,%s)',(id,name,email,password))
#         connection.commit()
#         cursor.close()
#         connection.close()

#         return 'done'
    


#contact file
def get_db_connection():
    return mysql.connect(**con)
@app.route('/submit',methods=['POST'])
def submit():
    if request.method=='POST':
        name=request.form['name']
        email=request.form['email']
        phone=request.form['phone']
        subject=request.form['subject']
        message=request.form['message']


        connection=get_db_connection()
        cursor=connection.cursor()

        cursor.execute('INSERT into tbl1(name,email,phone,subject,message) values (%s,%s,%s,%s,%s)',(name,email,phone,subject,message))
        connection.commit()
        cursor.close()
        connection.close()

        return 'done'
    
#review file

def get_db_connection():
    return mysql.connect(**con)
@app.route('/sub',methods=['POST'])
def sub1():
    if request.method=='POST':
        name=request.form['name']
        rating=request.form['rating']
    
        comment=request.form['comment']


        connection=get_db_connection()
        cursor=connection.cursor()

        cursor.execute('INSERT into tbl2(name,rating,comment) values (%s,%s,%s)',(name,rating,comment))
        connection.commit()
        cursor.close()
        connection.close()

        return 'done'
    



#feedback connection,....
def get_db_connection():
    return mysql.connect(**con)
@app.route('/sub2',methods=['POST'])
def sub2():
    if request.method=='POST':
        name=request.form['name']
        email=request.form['email']
        rating=request.form['rating']
        comment=request.form['comment']
        # message=request.form['message']


        connection=get_db_connection()
        cursor=connection.cursor()

        cursor.execute('INSERT into tbl3(name,email,rating,comment) values (%s,%s,%s,%s)',(name,email,rating,comment))
        connection.commit()
        cursor.close()
        connection.close()

        return 'done'









#read data/
# @app.route("/read" , methods=['GET'])
# def read():
#     con=get_db_connection()
#     cursor=con.cursor(dictionary=True)
#     cursor.execute("Select * from tbldata")
#     data=cursor.fetchall()
#     cursor.close()
#     con.close
#     return render_template("read.html",val=data)


# @app.route("/read1",methods=['GET'])
# def read():
#     con=get_db_connection()
#     cursor= con.cursor(dictionary=True)
#     cursor.execute( "select*from tbldata")
#     data=cursor.fetchall()
#     cursor.close()
#     con.close
#     return render_template("read1.html",val=data)

#upload file
# @app.route('/file')
# def file_h():
#     return render_template('upload.html')
# @app.route('/upload',methods=['POST'])
# def filesend():
#     if request.method=='POST':
#         if 'file' not in request.files:
#             return"no file part"
#         file=request.files['file']
#         if file.filename=='':
#             return"no selected file"
#         if file:
#             filename=source_file(file,filename)
#             file_path=os.path.join(app.config['UPLOAD _FOLDER'],filename)
#             os.makedirs(app.config['UPLOAD_FOLDER'],exist_ok=True)
#             file.save(file_path)
#             con=get_db_connection()











        


 

   




if __name__== "__main__":

    app.run(debug=True)

